Delivery Pack — Starter Pack
=============================

Use this pack in Develop & Deliver, once the required approvals are in place
and the team is moving into execution.

This zip contains:
  00-README.txt
  01-Delivery-Pack.docx  (main pack)

These files are v1 placeholders. Content will be expanded in later versions.
