Discovery Pack — Starter Pack
=============================

This zip contains starter placeholder files for the Discovery Pack.
These are v1 placeholders. Content will be expanded in future versions.

Files in this pack
------------------
01-Discovery-Pack.docx    Main pack — use this to capture what was learned
                         during discovery and support a next-step decision.

Note
----
The Discovery Pack is used in the Product Discovery stage of the product
lifecycle. It is a learning deliverable, not a planning or approval document.