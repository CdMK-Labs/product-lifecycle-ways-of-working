Discovery Pack — Starter Pack
==============================

Use this pack when an Opportunity Brief has been prioritised and the team
needs to understand the problem better before committing to a plan.

This zip contains:
  00-README.txt
  01-Discovery-Pack.docx  (main pack)

These files are v1 placeholders. Content will be expanded in later versions.
