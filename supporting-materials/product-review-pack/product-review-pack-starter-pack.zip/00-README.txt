Product Review Pack — Starter Pack
===================================

This zip contains starter placeholder files for the Product Review Pack.
These are v1 placeholders. Content will be expanded in future versions.

Files in this pack
------------------
01-Product-Review-Pack.docx    Main pack — use this to bring together
                               service health, usage and adoption signals,
                               and improvement decisions for recurring
                               live-product reviews.

Note
----
The Product Review Pack is used throughout Operations: Operate & Monitor,
Measure & Learn and Adapt & Optimize. Use it on a regular cadence and
update sections between reviews rather than rebuilding from scratch.