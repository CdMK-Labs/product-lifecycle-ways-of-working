Opportunity Brief — Starter Pack
=================================

Use this pack at the start of the lifecycle, when a problem or opportunity
needs framing before any further investment.

This zip contains:
  00-README.txt
  01-Opportunity-Brief.docx  (main pack)

These files are v1 placeholders. Content will be expanded in later versions.
