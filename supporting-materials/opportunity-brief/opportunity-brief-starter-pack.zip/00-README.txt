Opportunity Brief — Starter Pack
================================

This zip contains starter placeholder files for the Opportunity Brief.
These are v1 placeholders. Content will be expanded in future versions.

Files in this pack
------------------
01-Opportunity-Brief.docx    Main pack — use this to frame the problem or
                             opportunity and support a next-step decision.

Note
----
The Opportunity Brief is used in the Value Proposition stage of the product
lifecycle. It is a lightweight framing document, not a business case.