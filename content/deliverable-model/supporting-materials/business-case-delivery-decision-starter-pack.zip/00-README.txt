Business Case & Delivery Decision Pack — Starter Pack
======================================================

Use this pack in Align & Plan, when discovery is complete and the topic
needs formal approval before execution begins.

This zip contains:
  00-README.txt
  01-Business-Case-and-Delivery-Decision-Pack.docx  (main pack)
  Appendix-KPI.docx
  Appendix-Architecture.docx
  Appendix-Estimates-and-Financial.docx
  Appendix-Risk.docx

Not every commitment needs all four appendices in full.
Scale the depth to the size of the decision.

These files are v1 placeholders. Content will be expanded in later versions.
